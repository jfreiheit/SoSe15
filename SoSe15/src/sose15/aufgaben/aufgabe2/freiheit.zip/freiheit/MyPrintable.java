package sose15.aufgaben.aufgabe2.freiheit;

public interface MyPrintable {
	abstract public void printElement(Object element);
	abstract public void printElement(int index);
	abstract public void printAll();
}
