package sose15.aufgaben.aufgabe2.freiheit;

public interface MyComparable {
	abstract public boolean equal(Object set);
}
